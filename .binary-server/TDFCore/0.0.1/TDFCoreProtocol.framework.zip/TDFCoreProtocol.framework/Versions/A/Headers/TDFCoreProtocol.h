//
//  TDFCoreProtocol.h
//  TDFCoreProtocol
//
//  Created by tripleCC on 3/13/17.
//  Copyright © 2017 tripleCC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TDFCoreProtocol.
FOUNDATION_EXPORT double TDFCoreProtocolVersionNumber;

//! Project version string for TDFCoreProtocol.
FOUNDATION_EXPORT const unsigned char TDFCoreProtocolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TDFCoreProtocol/PublicHeader.h>

#if __has_include(<TDFCoreProtocol/TDFCoreProtocol.h>)
#import <TDFCoreProtocol/INameItem.h>
#import <TDFCoreProtocol/ITreeNode.h>
#import <TDFCoreProtocol/INameValueItem.h>
#import <TDFCoreProtocol/TDFViewControllerProtocol.h>
#else
#import "INameItem.h"
#import "ITreeNode.h"
#import "INameValueItem.h"
#import "TDFViewControllerProtocol.h"
#import "TDFSectionItemProtocol.h"
#endif
