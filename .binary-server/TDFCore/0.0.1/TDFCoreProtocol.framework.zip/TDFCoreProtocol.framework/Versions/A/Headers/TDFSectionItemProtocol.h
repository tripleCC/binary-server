//
//  TDFSectionItemProtocol.h
//  Pods
//
//  Created by tripleCC on 2017/12/22.
//

#ifndef TDFSectionItemProtocol_h
#define TDFSectionItemProtocol_h
#import <Foundation/Foundation.h>
@protocol TDFSectionItemProtocol <NSObject>
@end

#endif /* TDFSectionItemProtocol_h */
