#import <Foundation/Foundation.h>

@interface TDFCoreProtocolImplementation : NSObject
@end
