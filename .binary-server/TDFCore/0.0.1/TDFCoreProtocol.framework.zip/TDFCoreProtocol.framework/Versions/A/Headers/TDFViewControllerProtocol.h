//
//  TDFViewControllerProtocol.h
//  TDFCoreProtocol
//
//  Created by tripleCC on 2017/8/25.
//  Copyright © 2017年 tripleCC. All rights reserved.
//

#ifndef TDFViewControllerProtocol_h
#define TDFViewControllerProtocol_h
#import <Foundation/Foundation.h>

@protocol TDFViewControllerProtocol <NSObject>
@end

#endif /* TDFViewControllerProtocol_h */
